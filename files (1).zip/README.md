# Library Management REST API

A RESTful API for managing books in a library, built with **Java 17, Spring Boot 3, Spring Data JPA, H2 (in-memory DB)**. Implements full CRUD.

## 1. Run the project

```bash
mvn spring-boot:run
```
Server: `http://localhost:8080`. H2 console: `http://localhost:8080/h2-console` (JDBC URL `jdbc:h2:mem:librarydb`, user `sa`, no password).

## 2. Project structure

```
src/main/java/com/library
├── LibraryApplication.java
├── model/Book.java
├── repository/BookRepository.java
├── controller/BookController.java
└── exception/ (ResourceNotFoundException, GlobalExceptionHandler)
```

## 3. Resource: Book

| Field         | Type    | Rules            |
|---------------|---------|------------------|
| id            | Long    | auto-generated   |
| title         | String  | required         |
| author        | String  | required         |
| isbn          | String  | required, unique |
| publishedYear | Integer | >= 1000          |
| quantity      | Integer | >= 0             |

## 4. Endpoints

Base URL: `/api/books`

| Method | Endpoint        | Description                        | Success |
|--------|-----------------|------------------------------------|---------|
| POST   | /api/books      | Add a new book                     | 201     |
| GET    | /api/books      | List all books (`?author=` filter) | 200     |
| GET    | /api/books/{id} | Get one book                       | 200     |
| PUT    | /api/books/{id} | Update a book                      | 200     |
| DELETE | /api/books/{id} | Delete a book                      | 204     |

### POST /api/books
Request:
```json
{
  "title": "Clean Code",
  "author": "Robert C. Martin",
  "isbn": "9780132350884",
  "publishedYear": 2008,
  "quantity": 5
}
```
Response `201 Created`:
```json
{
  "id": 1,
  "title": "Clean Code",
  "author": "Robert C. Martin",
  "isbn": "9780132350884",
  "publishedYear": 2008,
  "quantity": 5
}
```

### GET /api/books
Response `200 OK`: array of books. Example filter: `GET /api/books?author=martin`

### GET /api/books/{id}
Response `200 OK`: one book. If missing, `404`:
```json
{ "timestamp": "...", "status": 404, "error": "Not Found", "message": "Book not found with id 99" }
```

### PUT /api/books/{id}
Request body same as POST. Response `200 OK` with the updated book.

### DELETE /api/books/{id}
Response `204 No Content`. `404` if the id does not exist.

## 5. Error responses

| Status | When                                      |
|--------|-------------------------------------------|
| 400    | Validation failed (missing/invalid field) |
| 404    | Book id not found                         |
| 409    | Duplicate ISBN                            |

Validation error example (`400`):
```json
{ "status": 400, "error": "Bad Request", "message": { "title": "title is required" } }
```

## 6. Test with curl

```bash
curl -X POST localhost:8080/api/books -H "Content-Type: application/json" \
  -d '{"title":"Clean Code","author":"Robert C. Martin","isbn":"9780132350884","publishedYear":2008,"quantity":5}'

curl localhost:8080/api/books
curl localhost:8080/api/books/1
curl "localhost:8080/api/books?author=martin"

curl -X PUT localhost:8080/api/books/1 -H "Content-Type: application/json" \
  -d '{"title":"Clean Code","author":"Robert C. Martin","isbn":"9780132350884","publishedYear":2008,"quantity":10}'

curl -X DELETE localhost:8080/api/books/1
```
These also work in Postman.

## 7. Design notes
- Nouns in URLs, HTTP verbs for actions
- Proper status codes (201, 204, 400, 404, 409)
- Stateless, JSON in/out
- Layered: Controller -> Repository -> DB
